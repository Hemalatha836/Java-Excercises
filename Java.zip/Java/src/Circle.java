
public class Circle extends Shape {
	public void print_circle() {
		System.out.println("Shape is circle");
	}

}
