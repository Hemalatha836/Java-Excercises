
public class ImmEmplyee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee1=new Employee("Hema","Reddy",23,"wipro","1.8");
		Employee employee2=new Employee("John","Robby",26,"tcs","3.9");
		System.out.println(employee1.getFirstname());
		System.out.println(employee1.getAge());
		System.out.println(employee2.getFirstname());
		System.out.println(employee2.getCompany());
		System.out.println(employee2.getExperience());
		System.out.println(employee1.getFirstname());
		System.out.println(employee1.getLastname());
		System.out.println(employee1.getAge());
		System.out.println(employee1.getCompany());
		System.out.println(employee1.getExperience());








	}

}
