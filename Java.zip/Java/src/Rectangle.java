
public class Rectangle extends Shape {
	public void print_rect() {
		System.out.println("Shape is Rectangle");
	}

}
