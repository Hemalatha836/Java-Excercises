
public class Shape {
	public void print_shape() {
		System.out.println("Shape");
	}

}
