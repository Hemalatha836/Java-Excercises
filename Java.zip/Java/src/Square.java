
public class Square extends Shape{
	public void print_square() {
		System.out.println("Shape is square");
	}

}
